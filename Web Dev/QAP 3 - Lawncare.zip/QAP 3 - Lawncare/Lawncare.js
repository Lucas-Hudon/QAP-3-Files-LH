// Desc: Invoice for Mo's Lawncare Services
// Author: Lucas Hudon
// Dates: July 10th - July 20th


var $ = function (id) {
  return document.getElementById(id);
};


// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});


// Define program constants.

const BORDER_SIZE = .04;  // Borders are 4% of the total square footage

const BORDER_COST = .35;  // Borders are charged at .35 cents per square foot of border

const LAWN_SIZE = .95;  // Lawn mowing is based on the remaining 95% of the lawn

const LAWN_MOWING_COST = .07;  // .07 cents per square foot of lawn

const FERTILIZER_TREAT = .05;  // .05 cents per square foot of entire property

const HST_RATE = .15;  // HST rate of 15%

const ENVIRONMENT_TAX = .014;  // Tax based on 1.4% of total charges


// Start main program here.

// Gather user inputs.

let CustName = prompt("Enter the customer name: ", "First Last");
let StreetAdd = prompt("Enter the street address: ");
let City = prompt("Enter the city: ", "St. John's");
let PhoneNum = prompt("Enter the phone number: ", "999-999-9999");
let TotSquareFeet = prompt("Enter the total square feet for the property: ", "9999");
TotSquareFeet = parseInt(TotSquareFeet);


// Perform program calculations.

let Border = TotSquareFeet * BORDER_SIZE;

let BorderCost = Border * BORDER_COST;

let Lawn = TotSquareFeet * LAWN_SIZE;

let MowingCost = Lawn * LAWN_MOWING_COST;

let FertCost = TotSquareFeet * FERTILIZER_TREAT;

let TotCharge = BorderCost + MowingCost + FertCost;

let HST = TotCharge * HST_RATE;

let EnvTax = TotCharge * ENVIRONMENT_TAX;

let InvoiceTot = TotCharge + HST + EnvTax;


// Display results as a table

document.writeln("<br />");
document.writeln("<table class='lawntable'>");

document.writeln("<tr class='yellowback'>");
document.writeln("<th colspan='2'>Mo's Lawncare Services - Customer Invoice</th>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td colspan='2'>");
document.writeln("<br /> Customer details: <br /><br />");
document.writeln("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + CustName + "<br />");
document.writeln("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + StreetAdd + "<br />");
document.writeln("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + City + PhoneNum + "<br /><br />");
document.writeln("Property size (in sq feet): " + TotSquareFeet + "<br /><br />");
document.writeln("</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Border cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(BorderCost) + "</td");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Mowing cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(MowingCost) + "</td");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Fertilizer cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(FertCost) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br /" + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Total charges:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(TotCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br /" + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Sales tax (HST):</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(HST) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Environmental tax:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(EnvTax) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br /" + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td>Invoice total:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(InvoiceTot) + "</td>");
document.writeln("</tr>");

document.writeln("<tr class='yellowback'>");
document.writeln("<th colspan='2'>Turning Lawns Into Landscapes</th>");
document.writeln("</tr>");

document. writeln("</table>");